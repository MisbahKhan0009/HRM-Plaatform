#!/usr/bin/env bash
# Usage: db-setup.sh staging|prod — migrate, seed baseline + first admin, demo data on staging only,
# then check the hrm_app grants. Reads the owner URL from this folder; never prints it.
set -euo pipefail
env=$1
S=/c/Users/padma/.hrm-secrets
cd "/c/Users/padma/OneDrive/Documents/Projects/HRM-Platform/HRM-Plaatform"
export DATABASE_URL; DATABASE_URL=$(cat "$S/neon-$env-owner.url")

echo "== migrate ($env)"
pnpm --filter @hrm/db db:migrate 2>&1 | grep -vE "postgres(ql)?://" | tail -8

echo "== seed ($env)"
SEED_COMPANY_NAME="Big-Matrix Solutions" SEED_ADMIN_EMAIL=mkhanmisbah007@gmail.com SEED_ADMIN_NAME="Misbah Khan" \
  SEED_ADMIN_ROLES=system_admin,hr_admin pnpm --filter @hrm/db db:seed 2>&1 | grep -vE "postgres(ql)?://" | tail -3

if [ "$env" = staging ]; then
  echo "== demo seed (staging)"
  SEED_DEMO_CONFIRM=staging pnpm --filter @hrm/db db:seed:demo 2>&1 | grep -vE "postgres(ql)?://" | tail -3
fi

echo "== hrm_app grants check ($env)"
APP_URL_FILE="$S/neon-$env-app.url" node --input-type=module -e "
  import { createRequire } from 'node:module';
  import fs from 'node:fs';
  const require = createRequire('C:/Users/padma/OneDrive/Documents/Projects/HRM-Platform/HRM-Plaatform/packages/db/package.json');
  const postgres = require('postgres');
  const sql = postgres(fs.readFileSync(process.env.APP_URL_FILE, 'utf8').trim(), { max: 1, onnotice: () => {} });
  const [c] = await sql\`select count(*)::int as n from companies\`;
  console.log('hrm_app can read companies:', c.n);
  try { await sql\`update audit_logs set action = action where false\`; console.log('UNEXPECTED: hrm_app may update audit_logs'); }
  catch (e) { console.log('audit_logs update denied:', e.code === '42501'); }
  await sql.end();
"
