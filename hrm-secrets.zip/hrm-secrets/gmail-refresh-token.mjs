// Gets a Gmail API refresh token (scope gmail.send) for the HRM sender and saves it to GMAIL_REFRESH_TOKEN.
// Prints the consent URL (contains only the public client ID) and status lines; never prints a token.
import http from 'node:http';
import fs from 'node:fs';
import crypto from 'node:crypto';

const dir = 'C:/Users/padma/.hrm-secrets/';
const clientId = fs.readFileSync(dir + 'GMAIL_CLIENT_ID', 'utf8').trim();
const clientSecret = fs.readFileSync(dir + 'GMAIL_CLIENT_SECRET', 'utf8').trim();
const redirectUri = 'http://localhost:8765/callback';
const state = crypto.randomBytes(16).toString('hex');

const auth = new URL('https://accounts.google.com/o/oauth2/v2/auth');
auth.search = new URLSearchParams({
  client_id: clientId,
  redirect_uri: redirectUri,
  response_type: 'code',
  scope: 'https://www.googleapis.com/auth/gmail.send',
  access_type: 'offline',
  prompt: 'consent',
  login_hint: 'mkhanmisbah007@gmail.com',
  state,
}).toString();
fs.writeFileSync(dir + 'gmail-consent.url', auth.toString());
console.log('consent URL written to gmail-consent.url');

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost:8765');
  if (url.pathname !== '/callback') { res.statusCode = 404; return res.end(); }
  if (url.searchParams.get('state') !== state) { res.statusCode = 400; res.end('state mismatch'); return; }
  const err = url.searchParams.get('error');
  if (err) { res.end('Consent was not given: ' + err); console.log('error from Google: ' + err); process.exit(1); }
  const r = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code: url.searchParams.get('code'),
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: redirectUri,
      grant_type: 'authorization_code',
    }),
  });
  const j = await r.json();
  if (!j.refresh_token) {
    res.end('No refresh token returned. You can close this tab.');
    console.log('token exchange failed: ' + (j.error || r.status) + ' ' + (j.error_description || ''));
    process.exit(1);
  }
  fs.writeFileSync(dir + 'GMAIL_REFRESH_TOKEN', j.refresh_token, { mode: 0o600 });
  res.end('HRM Gmail sender authorised. You can close this tab.');
  console.log(`refresh token saved (${j.refresh_token.length} chars), scope: ${j.scope}`);
  setTimeout(() => process.exit(0), 200);
});
server.listen(8765, '127.0.0.1', () => console.log('waiting for consent on http://localhost:8765/callback'));
setTimeout(() => { console.log('timeout'); process.exit(1); }, 60 * 60 * 1000);
