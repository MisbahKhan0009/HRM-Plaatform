#!/usr/bin/env bash
# Usage: clip-to-file.sh NAME — saves the clipboard to ./NAME, clears the clipboard, prints the length only.
set -euo pipefail
umask 077
S=/c/Users/padma/.hrm-secrets
powershell.exe -NoProfile -Command "Get-Clipboard -Raw" | tr -d '\r\n' > "$S/$1"
n=$(wc -c < "$S/$1")
powershell.exe -NoProfile -Command "Set-Clipboard -Value ' '"
[ "$n" -gt 8 ] || { echo "clipboard looks empty ($n chars)"; exit 1; }
echo "$1 saved ($n chars); clipboard cleared"
