#!/usr/bin/env bash
# Usage: clip-to-secret.sh NAME env1 [env2 ...]
# Saves the clipboard to ./NAME, sets it as a GitHub Actions secret in each environment,
# then clears the clipboard. Prints the value length only, never the value.
set -euo pipefail
umask 077
S=/c/Users/padma/.hrm-secrets
GHR=MisbahKhan0009/HRM-Plaatform
export PATH="$PATH:/c/Program Files/GitHub CLI"
name=$1; shift
powershell.exe -NoProfile -Command "Get-Clipboard -Raw" | tr -d '\r\n' > "$S/$name"
n=$(wc -c < "$S/$name")
[ "$n" -gt 8 ] || { echo "clipboard looks empty ($n chars)"; exit 1; }
for env in "$@"; do gh secret set "$name" -R "$GHR" --env "$env" < "$S/$name"; done
powershell.exe -NoProfile -Command "Set-Clipboard -Value ' '"
echo "$name set in [$*] ($n chars); clipboard cleared"
