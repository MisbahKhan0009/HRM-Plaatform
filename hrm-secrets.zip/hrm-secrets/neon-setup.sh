#!/usr/bin/env bash
# Creates hrm_app on both Neon branches, stores connection strings in this folder,
# creates the Hyperdrive configs and sets the Neon owner URLs as GitHub environment secrets.
# Prints status and Hyperdrive IDs only; never prints a secret value.
set -euo pipefail
umask 077
S=/c/Users/padma/.hrm-secrets
REPO="/c/Users/padma/OneDrive/Documents/Projects/HRM-Platform/HRM-Plaatform"
P=late-credit-28329566
GHR=MisbahKhan0009/HRM-Plaatform
export PATH="$PATH:/c/Program Files/GitHub CLI"
neon() { (cd "$S" && pnpm dlx neonctl@8.10.3 "$@"); }

for pair in staging:staging production:prod; do
  br=${pair%%:*}; env=${pair##*:}
  echo "== branch $br"
  neon connection-string "$br" --project-id "$P" --role-name neondb_owner --database-name neondb 2>/dev/null | tr -d '\r\n' > "$S/neon-$env-owner.url"
  [ -s "$S/neon-$env-owner.url" ] || { echo "no owner URL for $br"; exit 1; }
  [ -s "$S/neon-$env-app.pw" ] || openssl rand -hex 24 | tr -d '\r\n' > "$S/neon-$env-app.pw"
  OWNER_URL_FILE="$S/neon-$env-owner.url" APP_PW_FILE="$S/neon-$env-app.pw" APP_URL_FILE="$S/neon-$env-app.url" \
  node --input-type=module -e "
    import { createRequire } from 'node:module';
    import fs from 'node:fs';
    const require = createRequire('C:/Users/padma/OneDrive/Documents/Projects/HRM-Platform/HRM-Plaatform/packages/db/package.json');
    const postgres = require('postgres');
    const ownerUrl = fs.readFileSync(process.env.OWNER_URL_FILE, 'utf8').trim();
    const pw = fs.readFileSync(process.env.APP_PW_FILE, 'utf8').trim();
    const sql = postgres(ownerUrl, { max: 1, onnotice: () => {} });
    const exists = await sql\`select 1 from pg_roles where rolname = 'hrm_app'\`;
    if (exists.length) await sql.unsafe(\`ALTER ROLE hrm_app LOGIN PASSWORD '\${pw}'\`);
    else await sql.unsafe(\`CREATE ROLE hrm_app LOGIN PASSWORD '\${pw}'\`);
    await sql.unsafe('GRANT CONNECT ON DATABASE neondb TO hrm_app');
    await sql.unsafe('GRANT USAGE ON SCHEMA public TO hrm_app');
    await sql.end();
    const u = new URL(ownerUrl);
    u.username = 'hrm_app'; u.password = pw; u.search = '?sslmode=require';
    fs.writeFileSync(process.env.APP_URL_FILE, u.toString());
    const app = postgres(u.toString(), { max: 1 });
    const [r] = await app\`select current_user as who\`;
    await app.end();
    console.log('hrm_app ' + (exists.length ? 'updated' : 'created') + ', connects as ' + r.who);
  "
done

cd "$REPO/apps/api"
for pair in staging:staging prod:prod; do
  env=${pair%%:*}; name="hrm-$env-db"
  if pnpm exec wrangler hyperdrive list 2>/dev/null | grep -q "$name"; then
    echo "hyperdrive $name exists, updating connection string"
    id=$(pnpm exec wrangler hyperdrive list 2>/dev/null | grep "$name" | grep -oE '[0-9a-f]{32}' | head -1)
    pnpm exec wrangler hyperdrive update "$id" --connection-string="$(cat "$S/neon-$env-app.url")" >/dev/null 2>&1 && echo "updated"
  else
    pnpm exec wrangler hyperdrive create "$name" --connection-string="$(cat "$S/neon-$env-app.url")" 2>&1 | grep -iE '"id"|created|error' | grep -v -i password || true
  fi
done
echo "== hyperdrive ids"
pnpm exec wrangler hyperdrive list 2>/dev/null | grep -E 'hrm-(staging|prod)-db' | grep -oE '[0-9a-f]{32}.*hrm-(staging|prod)-db|hrm-(staging|prod)-db.*[0-9a-f]{32}' | sed -E 's/postgres(ql)?:\/\/[^ ]*//g'

echo "== github secrets"
gh secret set NEON_STAGING_OWNER_URL -R "$GHR" --env staging < "$S/neon-staging-owner.url"
gh secret set NEON_PROD_OWNER_URL -R "$GHR" --env production < "$S/neon-prod-owner.url"
gh secret set NEON_PROD_OWNER_URL -R "$GHR" --env backups < "$S/neon-prod-owner.url"
echo done
