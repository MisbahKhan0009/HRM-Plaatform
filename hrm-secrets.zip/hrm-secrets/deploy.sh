#!/usr/bin/env bash
# Usage: deploy.sh staging|production — build the SPA, deploy the Worker, set Worker secrets, redeploy.
# Secret values come from files in this folder and are never printed.
set -euo pipefail
umask 077
env=$1
short=$([ "$env" = production ] && echo prod || echo staging)
S=/c/Users/padma/.hrm-secrets
REPO=/c/Users/padma/OneDrive/Documents/Projects/HRM-Platform/HRM-Plaatform
cd "$REPO"
ver=$(git rev-parse --short=12 HEAD)

[ -s "$S/BETTER_AUTH_SECRET_$short" ] || openssl rand -base64 48 | tr -d '\r\n' > "$S/BETTER_AUTH_SECRET_$short"

echo "== build web ($env)"
VITE_ENV=$env VITE_RELEASE=$ver pnpm --filter @hrm/web build 2>&1 | tail -2
[ "$env" = production ] && find apps/web/dist -name '*.map' -delete

cd apps/api
echo "== deploy ($env, APP_VERSION=$ver)"
pnpm exec wrangler deploy --env "$env" --var "APP_VERSION:$ver" 2>&1 | grep -E "Uploaded|Deployed|https://|Current Version|ERROR|error" | head -8

echo "== secrets ($env)"
ENV_NAME=$env SHORT=$short node --input-type=module -e "
  import fs from 'node:fs';
  const d = 'C:/Users/padma/.hrm-secrets/';
  const r = (f) => fs.existsSync(d + f) ? fs.readFileSync(d + f, 'utf8').trim() : '';
  const s = {
    BETTER_AUTH_SECRET: r('BETTER_AUTH_SECRET_' + process.env.SHORT),
    GMAIL_CLIENT_ID: r('GMAIL_CLIENT_ID'),
    GMAIL_CLIENT_SECRET: r('GMAIL_CLIENT_SECRET'),
    GMAIL_REFRESH_TOKEN: r('GMAIL_REFRESH_TOKEN'),
    GMAIL_SENDER: 'mkhanmisbah007@gmail.com',
    SENTRY_DSN: r('SENTRY_DSN_API'),
  };
  if (process.env.ENV_NAME === 'staging') s.MAIL_ALLOWLIST = 'mkhanmisbah007@gmail.com';
  for (const [k, v] of Object.entries(s)) if (!v) { delete s[k]; console.log('missing ' + k); }
  fs.writeFileSync(d + 'worker-secrets.json', JSON.stringify(s), { mode: 0o600 });
  console.log('secret names: ' + Object.keys(s).join(', '));
"
pnpm exec wrangler secret bulk "$S/worker-secrets.json" --env "$env" 2>&1 | grep -E "Success|Finished|ERROR|error|✨" | head -5
rm -f "$S/worker-secrets.json"

echo "== redeploy ($env)"
pnpm exec wrangler deploy --env "$env" --var "APP_VERSION:$ver" 2>&1 | grep -E "Deployed|https://|Current Version|ERROR|error" | head -5
pnpm exec wrangler secret list --env "$env" 2>&1 | grep -oE '"name": "[A-Z_]+"' | tr '\n' ' '; echo
