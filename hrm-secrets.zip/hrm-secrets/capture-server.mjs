// Receives GMAIL_CLIENT_ID / GMAIL_CLIENT_SECRET from the Google Cloud console tab and writes them to files.
// Listens on 127.0.0.1 only, accepts only those two names, prints lengths only, exits once both are saved.
import http from 'node:http';
import fs from 'node:fs';

const dir = 'C:/Users/padma/.hrm-secrets/';
const wanted = new Set(['GMAIL_CLIENT_ID', 'GMAIL_CLIENT_SECRET']);
const saved = new Set();

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', 'https://console.cloud.google.com');
  res.setHeader('Access-Control-Allow-Headers', 'content-type');
  res.setHeader('Access-Control-Allow-Private-Network', 'true');
  if (req.method === 'OPTIONS') return res.end();
  let body = '';
  req.on('data', (c) => (body += c));
  req.on('end', () => {
    try {
      const data = JSON.parse(body);
      for (const [k, v] of Object.entries(data)) {
        if (wanted.has(k) && typeof v === 'string' && v.trim().length > 10) {
          fs.writeFileSync(dir + k, v.trim(), { mode: 0o600 });
          saved.add(k);
          console.log(`saved ${k} (${v.trim().length} chars)`);
        }
      }
      res.end('ok');
      if (saved.size === wanted.size) setTimeout(() => process.exit(0), 200);
    } catch {
      res.statusCode = 400;
      res.end('bad');
    }
  });
});
server.listen(8766, '127.0.0.1', () => console.log('listening'));
setTimeout(() => { console.log('timeout'); process.exit(1); }, 15 * 60 * 1000);
